Hi! If you're reading this, its important you know that you have to remove -doodleNEW from every file.
If you don't, the gamesheet wont work. (and the plist) so your Geometry Dash will be broken.
Please make sure you know that this is very important and this doodle NEW GD pack is made by me.
Thank you.


-Beany. discord: @f2perxd